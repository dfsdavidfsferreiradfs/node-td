function minhaFuncao() {
    console.log("Olá do meu módulo!");
    }
    
    module.exports = {
    minhaFuncao: minhaFuncao
    };